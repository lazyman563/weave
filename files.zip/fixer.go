package ai

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
)

type FixRequest struct {
	Selector    string
	Instruction string
	HTML        string
	FullPage    string
}

type FixResult struct {
	FixedHTML   string
	Explanation string
}

type claudeMsg struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

type claudeReq struct {
	Model     string      `json:"model"`
	MaxTokens int         `json:"max_tokens"`
	Messages  []claudeMsg `json:"messages"`
}

type claudeResp struct {
	Content []struct {
		Text string `json:"text"`
	} `json:"content"`
	Error *struct {
		Message string `json:"message"`
	} `json:"error"`
}

func Fix(r *FixRequest) (*FixResult, error) {
	apiKey := os.Getenv("ANTHROPIC_API_KEY")
	if apiKey == "" {
		return nil, fmt.Errorf("ANTHROPIC_API_KEY não definida. Execute: export ANTHROPIC_API_KEY=sua_chave")
	}

	prompt := fmt.Sprintf(`Você é um especialista em HTML/CSS/JavaScript.

O usuário selecionou este elemento HTML:
<elemento>
%s
</elemento>

Instrução do usuário:
"%s"

Retorne APENAS um JSON válido neste formato exato (sem markdown, sem código extra):
{"fixed_html": "HTML_CORRIGIDO_AQUI", "explanation": "O que foi alterado"}

O HTML corrigido deve ser funcional e aplicar exatamente o que o usuário pediu.`, r.HTML, r.Instruction)

	payload := claudeReq{
		Model:     "claude-sonnet-4-20250514",
		MaxTokens: 1000,
		Messages:  []claudeMsg{{Role: "user", Content: prompt}},
	}

	body, _ := json.Marshal(payload)
	req, _ := http.NewRequest("POST", "https://api.anthropic.com/v1/messages", bytes.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("x-api-key", apiKey)
	req.Header.Set("anthropic-version", "2023-06-01")

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("erro ao chamar API: %w", err)
	}
	defer resp.Body.Close()

	respBytes, _ := io.ReadAll(resp.Body)
	var cr claudeResp
	if err := json.Unmarshal(respBytes, &cr); err != nil {
		return nil, fmt.Errorf("resposta inválida da API")
	}

	if cr.Error != nil {
		return nil, fmt.Errorf("erro da API: %s", cr.Error.Message)
	}

	if len(cr.Content) == 0 {
		return nil, fmt.Errorf("resposta vazia da API")
	}

	var result struct {
		FixedHTML   string `json:"fixed_html"`
		Explanation string `json:"explanation"`
	}
	if err := json.Unmarshal([]byte(cr.Content[0].Text), &result); err != nil {
		return &FixResult{Explanation: cr.Content[0].Text}, nil
	}

	return &FixResult{
		FixedHTML:   result.FixedHTML,
		Explanation: result.Explanation,
	}, nil
}

func AnalyzePage(html string, expectations []string) (string, error) {
	apiKey := os.Getenv("ANTHROPIC_API_KEY")
	if apiKey == "" {
		return "", fmt.Errorf("ANTHROPIC_API_KEY não definida")
	}

	expectStr := ""
	for _, e := range expectations {
		expectStr += "- " + e + "\n"
	}

	prompt := fmt.Sprintf(`Analise este HTML e diga se os seguintes elementos estão presentes:
%s

HTML:
%s

Responda em português, de forma direta e técnica. Liste o que foi encontrado e o que está faltando.`, expectStr, truncate(html, 3000))

	payload := claudeReq{
		Model:     "claude-sonnet-4-20250514",
		MaxTokens: 500,
		Messages:  []claudeMsg{{Role: "user", Content: prompt}},
	}

	body, _ := json.Marshal(payload)
	req, _ := http.NewRequest("POST", "https://api.anthropic.com/v1/messages", bytes.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("x-api-key", apiKey)
	req.Header.Set("anthropic-version", "2023-06-01")

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	respBytes, _ := io.ReadAll(resp.Body)
	var cr claudeResp
	json.Unmarshal(respBytes, &cr)

	if len(cr.Content) == 0 {
		return "", fmt.Errorf("sem resposta da IA")
	}
	return cr.Content[0].Text, nil
}

func truncate(s string, max int) string {
	if len(s) <= max {
		return s
	}
	return s[:max] + "\n...[truncado]"
}
