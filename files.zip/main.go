package main

import (
	"github.com/weave/cmd"
)

func main() {
	cmd.Execute()
}
